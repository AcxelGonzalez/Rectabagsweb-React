import { BrowserRouter, Routes, Route } from "react-router-dom";

import Layout from "./components/Layout";
import Home from "./pages/Home";
import Catalogo from "./pages/Catalogo";
import ProductoDetalle from "./pages/ProductoDetalle";
import Blog from "./pages/Blog";
import ImpactoAmbiental from "./pages/ImpactoAmbiental";
import Contacto from "./pages/Contacto";
import QuienesSomos from "./pages/QuienesSomos";
import TerminosCompra from "./pages/TerminosCompra";
import TerminosRegistro from "./pages/TerminosRegistro";
import PaginaEnConstruccion from "./pages/PaginaEnConstruccion";

function App() {
    return (
        <BrowserRouter>
            <Routes>
                {/* Layout comparte el encabezado y pie de página entre todas las rutas. */}
                <Route element={<Layout />}>
                    <Route path="/" element={<Home />} />
                    <Route path="/catalogo" element={<Catalogo />} />
                    <Route path="/producto/:id" element={<ProductoDetalle />} />
                    <Route path="/blog" element={<Blog />} />
                    <Route path="/contacto" element={<Contacto />} />
                    <Route path="/impacto-ambiental" element={<ImpactoAmbiental />} />
                    <Route path="/QuienesSomos" element={<QuienesSomos />} />
                    <Route path="/terminos-compra" element={<TerminosCompra />} />
                    <Route path="/terminos-registro" element={<TerminosRegistro />} />
                    <Route path="/login" element={<PaginaEnConstruccion titulo="Iniciar Sesión" />} />
                    <Route path="/registro" element={<PaginaEnConstruccion titulo="Registro" />} />
                    <Route path="/carrito" element={<PaginaEnConstruccion titulo="Carrito" />} />
                    <Route path="/perfil" element={<PaginaEnConstruccion titulo="Mi Perfil" />} />
                    <Route path="*" element={<PaginaEnConstruccion titulo="Página no encontrada" />} />
                </Route>
            </Routes>
        </BrowserRouter>
    );
}

export default App;
